
package com.example.sensorkit.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF008000)
val GreenSoft = Color(0xFF68BA7F)
val Snow = Color(0xFFFFFAFA)
